package com.as6;

public class InsufficientBalanceException extends Exception{
	
	public InsufficientBalanceException(){
		//calling the parent constructor super("Insuffient Balance in the account");
		}
}
