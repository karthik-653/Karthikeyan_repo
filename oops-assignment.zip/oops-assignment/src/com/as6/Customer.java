package com.as6;

@Data
@AllArgsConstructor
public class Customer {
	private int customerId;
	private String customerName;
	private boolean loanAvailed;


}
