package com.as8;

public class InsufficientFundException extends Exception{
	public InsufficientFundException(String msg){
		//passing the message to the parent constructor
		super();
	}
}
