package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Blogs;
import com.entity.Owner;
import com.repo.BlogRepository;
import com.repo.OwnerRepository;

@Service
public class AddAppImpl implements AppDAO{
	
	@Autowired
	private OwnerRepository repo;
	
	@Autowired
	private BlogRepository blogrepo;

	@Override
	public void addOwner(Owner owner) {
		repo.save(owner);
		
	}

	@Override
	public void addBlog(int owner_id) {
		Owner owner = repo.findById(owner_id).get();
		List<Blogs> blogsList = new ArrayList<Blogs>();
		
		Blogs blogs1 = new Blogs("Spring", "java", "useless info");
		blogs1.setOwner(owner);
		blogsList.add(blogs1);
		
		Blogs blogs2 = new Blogs("Hibernate", "java advanced", "useful info");
		blogs2.setOwner(owner);
		blogsList.add(blogs2);
		
		owner.setBlogList(blogsList);
		repo.save(owner);
	}

	@Override
	public void addOwnerAndBlogs(Owner ownerData) {
		// TODO Auto-generated method stub
		List<Blogs> blogs = new ArrayList<Blogs>();
		for(Blogs blogin: ownerData.getBlogList()) {
			Blogs blog = new Blogs(blogin.getTitle(), blogin.getCategory(), blogin.getContent());
			blog.setOwner(ownerData);
			blogs.add(blog);
		}
		ownerData.setBlogList(blogs);
		repo.save(ownerData);
		
	}

	@Override
	public String findOwnerName(int blogid) {

		return blogrepo.findById(blogid).get().getOwner().getName();
	}

	@Override
	public Blogs findBlogs(int blogid) {
		return blogrepo.findById(blogid).get();
	}

	@Override
	public void deleteOwner(int ownerID) {
		repo.deleteById(ownerID);
		
	}
	

}