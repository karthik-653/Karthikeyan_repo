package com.service;

import com.entity.Blogs;
import com.entity.Owner;

public interface AppDAO {
	public void addOwner(Owner owner);
	public void addBlog(int owner_id);
	public void addOwnerAndBlogs(Owner owner);
	public String findOwnerName(int blogid);
	public Blogs findBlogs(int blogid);
	public void deleteOwner(int ownerID);
}
